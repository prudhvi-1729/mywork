from django.apps import AppConfig


class PizzaappConfig(AppConfig):
    name = 'pizzaapp'
